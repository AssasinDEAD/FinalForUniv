export interface Notification {
  id?: string;
  title: string;
  content: string;
  created_at?: string;
  updated_at?: string;
  imageUrl?: string;
}
